require 'test_helper'

class SpendTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
