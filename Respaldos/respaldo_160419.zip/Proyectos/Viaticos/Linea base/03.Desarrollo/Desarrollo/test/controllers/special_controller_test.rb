require 'test_helper'

class SpecialControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
