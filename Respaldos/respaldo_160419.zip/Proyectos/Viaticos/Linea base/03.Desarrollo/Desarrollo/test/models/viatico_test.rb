require 'test_helper'

class ViaticoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
