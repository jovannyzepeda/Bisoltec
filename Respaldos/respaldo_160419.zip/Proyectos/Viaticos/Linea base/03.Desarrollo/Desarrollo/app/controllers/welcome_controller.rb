class WelcomeController < ApplicationController
	before_action :auth

  def index

  end 
end
